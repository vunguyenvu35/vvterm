// Package sqlitedb is the SQLite adapter: one database file (vvterm.db) holds hosts, groups,
// identities, port forwards and the encrypted vault. It implements store.Persister and
// vault.Persister, so the rest of the app is unaware of the storage engine.
package sqlitedb

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"net/url"
	"os"
	"path/filepath"
	"time"

	_ "modernc.org/sqlite" // pure-Go driver, no CGO

	"vvterm/internal/domain"
	"vvterm/internal/vault"
)

// DB wraps the connection and exposes the persisters.
type DB struct{ db *sql.DB }

// schemaVersion 3 and 4 are the same idempotent step (see ensureAdditions): a database that stopped at 3 on
// an intermediate build has only some of the additions, and 4 completes it.
const schemaVersion = 4

var migrations = []string{
	// v1
	`CREATE TABLE groups (
		id TEXT PRIMARY KEY, name TEXT NOT NULL, parent_id TEXT NOT NULL DEFAULT '', color TEXT NOT NULL DEFAULT '',
		sort_order INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL, deleted_at TEXT);
	CREATE TABLE hosts (
		id TEXT PRIMARY KEY, label TEXT NOT NULL, group_id TEXT NOT NULL DEFAULT '', hostname TEXT NOT NULL,
		port INTEGER NOT NULL, username TEXT NOT NULL DEFAULT '', identity_id TEXT NOT NULL DEFAULT '',
		jump_host_id TEXT NOT NULL DEFAULT '', env TEXT NOT NULL DEFAULT '', tags TEXT NOT NULL DEFAULT '[]',
		keepalive_sec INTEGER NOT NULL DEFAULT 30, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, deleted_at TEXT);
	CREATE INDEX idx_hosts_group ON hosts(group_id);
	CREATE TABLE identities (
		id TEXT PRIMARY KEY, name TEXT NOT NULL, username TEXT NOT NULL DEFAULT '', auth_type TEXT NOT NULL,
		secret_ref TEXT NOT NULL DEFAULT '', public_key TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL, deleted_at TEXT);
	CREATE TABLE port_forwards (
		id TEXT PRIMARY KEY, host_id TEXT NOT NULL, type TEXT NOT NULL, bind_addr TEXT NOT NULL, bind_port INTEGER NOT NULL,
		dest_host TEXT NOT NULL DEFAULT '', dest_port INTEGER NOT NULL DEFAULT 0, auto_start INTEGER NOT NULL DEFAULT 0,
		allow_public_bind INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL, deleted_at TEXT);
	CREATE INDEX idx_forwards_host ON port_forwards(host_id);
	CREATE TABLE secrets (
		id TEXT PRIMARY KEY, kind TEXT NOT NULL, nonce BLOB, ciphertext BLOB, updated_at TEXT NOT NULL, deleted_at TEXT);
	CREATE TABLE vault_header (id INTEGER PRIMARY KEY CHECK (id = 1), data TEXT NOT NULL);`,
	// v2: snippets
	`CREATE TABLE snippets (
		id TEXT PRIMARY KEY, label TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', script TEXT NOT NULL,
		updated_at TEXT NOT NULL, deleted_at TEXT);`,
}

// Open opens (creating and migrating if needed) the database at path with mode 0600.
func Open(path string) (*DB, error) {
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return nil, err
	}
	q := url.Values{}
	q.Add("_pragma", "busy_timeout(5000)")
	q.Add("_pragma", "journal_mode(WAL)")
	q.Add("_pragma", "synchronous(NORMAL)")
	q.Add("_pragma", "foreign_keys(1)")
	db, err := sql.Open("sqlite", "file:"+path+"?"+q.Encode())
	if err != nil {
		return nil, err
	}
	db.SetMaxOpenConns(1) // single writer; avoids SQLITE_BUSY between the store and the vault
	d := &DB{db: db}
	if err := d.migrate(); err != nil {
		db.Close()
		return nil, err
	}
	_ = os.Chmod(path, 0o600)
	return d, nil
}

func (d *DB) Close() error { return d.db.Close() }

func (d *DB) migrate() error {
	var v int
	if err := d.db.QueryRow(`PRAGMA user_version`).Scan(&v); err != nil {
		return err
	}
	if v > schemaVersion {
		return fmt.Errorf("database schema v%d is newer than this app supports (v%d)", v, schemaVersion)
	}
	for ; v < schemaVersion; v++ {
		tx, err := d.db.Begin()
		if err != nil {
			return err
		}
		if v < len(migrations) {
			_, err = tx.Exec(migrations[v])
		} else {
			err = ensureAdditions(tx)
		}
		if err != nil {
			tx.Rollback()
			return fmt.Errorf("migrate to v%d: %w", v+1, err)
		}
		if _, err := tx.Exec(fmt.Sprintf(`PRAGMA user_version = %d`, v+1)); err != nil {
			tx.Rollback()
			return err
		}
		if err := tx.Commit(); err != nil {
			return err
		}
	}
	// Columns added later are listed in `additions` and are checked on every open, so a new one never needs a
	// version of its own: a database already at the newest version still gets it.
	tx, err := d.db.Begin()
	if err != nil {
		return err
	}
	if err := ensureAdditions(tx); err != nil {
		tx.Rollback()
		return fmt.Errorf("add columns: %w", err)
	}
	return tx.Commit()
}

// additions are the columns added after the first two schema versions. They are added only when missing, so
// the step can run on a database that already has some of them, and twice.
var additions = []struct{ table, column, def string }{
	{"hosts", "os", "TEXT NOT NULL DEFAULT ''"},               // server type: the icon
	{"hosts", "telnet_enabled", "INTEGER NOT NULL DEFAULT 0"}, // Telnet as a second way in
	{"hosts", "telnet_port", "INTEGER NOT NULL DEFAULT 0"},
	{"hosts", "terminal_theme", "TEXT NOT NULL DEFAULT ''"},  // a theme of its own
	{"hosts", "telnet_username", "TEXT NOT NULL DEFAULT ''"}, // its own login
	{"hosts", "telnet_encoding", "TEXT NOT NULL DEFAULT ''"},
	{"port_forwards", "label", "TEXT NOT NULL DEFAULT ''"},    // a name for a rule
	{"identities", "certificate", "TEXT NOT NULL DEFAULT ''"}, // OpenSSH user certificate
}

const activityTable = `CREATE TABLE IF NOT EXISTS activity_log (
		id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, kind TEXT NOT NULL, host_id TEXT NOT NULL DEFAULT '',
		host_label TEXT NOT NULL DEFAULT '', message TEXT NOT NULL, ok INTEGER NOT NULL DEFAULT 1)`

func ensureAdditions(tx *sql.Tx) error {
	have := map[string]map[string]bool{}
	for _, a := range additions {
		if have[a.table] == nil {
			cols := map[string]bool{}
			rows, err := tx.Query(fmt.Sprintf(`PRAGMA table_info(%s)`, a.table))
			if err != nil {
				return err
			}
			for rows.Next() {
				var cid, notnull, pk int
				var name, typ string
				var dflt sql.NullString
				if err := rows.Scan(&cid, &name, &typ, &notnull, &dflt, &pk); err != nil {
					rows.Close()
					return err
				}
				cols[name] = true
			}
			rows.Close()
			have[a.table] = cols
		}
		if have[a.table][a.column] {
			continue
		}
		if _, err := tx.Exec(fmt.Sprintf(`ALTER TABLE %s ADD COLUMN %s %s`, a.table, a.column, a.def)); err != nil {
			return fmt.Errorf("add %s.%s: %w", a.table, a.column, err)
		}
	}
	_, err := tx.Exec(activityTable)
	return err
}

// ---- time helpers ----

func ts(t time.Time) string { return t.UTC().Format(time.RFC3339Nano) }

func tsNull(t *time.Time) any {
	if t == nil {
		return nil
	}
	return ts(*t)
}

func parseTS(s string) time.Time {
	t, _ := time.Parse(time.RFC3339Nano, s)
	return t
}

func parseTSNull(s sql.NullString) *time.Time {
	if !s.Valid {
		return nil
	}
	t := parseTS(s.String)
	return &t
}

// ---- store.Persister ----

// StorePersister returns the persister for hosts, groups, identities and forwards.
func (d *DB) StorePersister() StorePersister { return StorePersister{d.db} }

type StorePersister struct{ db *sql.DB }

// Load reads every row; found is false for a database that has never been saved to.
func (p StorePersister) Load() (domain.Data, bool, error) {
	var data domain.Data
	data.Version = 1
	rows, err := p.db.Query(`SELECT id,name,parent_id,color,sort_order,updated_at,deleted_at FROM groups ORDER BY rowid`)
	if err != nil {
		return data, false, err
	}
	for rows.Next() {
		var g domain.Group
		var upd string
		var del sql.NullString
		if err := rows.Scan(&g.ID, &g.Name, &g.ParentID, &g.Color, &g.SortOrder, &upd, &del); err != nil {
			rows.Close()
			return data, false, err
		}
		g.UpdatedAt, g.DeletedAt = parseTS(upd), parseTSNull(del)
		data.Groups = append(data.Groups, g)
	}
	rows.Close()

	rows, err = p.db.Query(`SELECT id,label,group_id,hostname,port,username,identity_id,jump_host_id,env,tags,keepalive_sec,created_at,updated_at,deleted_at,os,telnet_enabled,telnet_port,terminal_theme,telnet_username,telnet_encoding FROM hosts ORDER BY rowid`)
	if err != nil {
		return data, false, err
	}
	for rows.Next() {
		var h domain.Host
		var env, tags, cr, upd string
		var telnet int
		var del sql.NullString
		if err := rows.Scan(&h.ID, &h.Label, &h.GroupID, &h.Hostname, &h.Port, &h.Username, &h.IdentityID, &h.JumpHostID, &env, &tags, &h.KeepaliveSec, &cr, &upd, &del, &h.OS, &telnet, &h.TelnetPort, &h.TerminalTheme, &h.TelnetUsername, &h.TelnetEncoding); err != nil {
			rows.Close()
			return data, false, err
		}
		h.Env = domain.Env(env)
		h.TelnetEnabled = telnet != 0
		_ = json.Unmarshal([]byte(tags), &h.Tags)
		h.CreatedAt, h.UpdatedAt, h.DeletedAt = parseTS(cr), parseTS(upd), parseTSNull(del)
		data.Hosts = append(data.Hosts, h)
	}
	rows.Close()

	rows, err = p.db.Query(`SELECT id,name,username,auth_type,secret_ref,public_key,updated_at,deleted_at,certificate FROM identities ORDER BY rowid`)
	if err != nil {
		return data, false, err
	}
	for rows.Next() {
		var x domain.Identity
		var at, upd string
		var del sql.NullString
		if err := rows.Scan(&x.ID, &x.Name, &x.Username, &at, &x.SecretRef, &x.PublicKey, &upd, &del, &x.Certificate); err != nil {
			rows.Close()
			return data, false, err
		}
		x.AuthType = domain.AuthType(at)
		x.UpdatedAt, x.DeletedAt = parseTS(upd), parseTSNull(del)
		data.Identities = append(data.Identities, x)
	}
	rows.Close()

	rows, err = p.db.Query(`SELECT id,host_id,type,bind_addr,bind_port,dest_host,dest_port,auto_start,allow_public_bind,updated_at,deleted_at,label FROM port_forwards ORDER BY rowid`)
	if err != nil {
		return data, false, err
	}
	for rows.Next() {
		var f domain.PortForward
		var typ, upd string
		var auto, pub int
		var del sql.NullString
		if err := rows.Scan(&f.ID, &f.HostID, &typ, &f.BindAddr, &f.BindPort, &f.DestHost, &f.DestPort, &auto, &pub, &upd, &del, &f.Label); err != nil {
			rows.Close()
			return data, false, err
		}
		f.Type, f.AutoStart, f.AllowPublicBind = domain.ForwardType(typ), auto != 0, pub != 0
		f.UpdatedAt, f.DeletedAt = parseTS(upd), parseTSNull(del)
		data.Forwards = append(data.Forwards, f)
	}
	rows.Close()

	rows, err = p.db.Query(`SELECT id,label,description,script,updated_at,deleted_at FROM snippets ORDER BY rowid`)
	if err != nil {
		return data, false, err
	}
	for rows.Next() {
		var x domain.Snippet
		var upd string
		var del sql.NullString
		if err := rows.Scan(&x.ID, &x.Label, &x.Description, &x.Script, &upd, &del); err != nil {
			rows.Close()
			return data, false, err
		}
		x.UpdatedAt, x.DeletedAt = parseTS(upd), parseTSNull(del)
		data.Snippets = append(data.Snippets, x)
	}
	rows.Close()

	found := len(data.Groups)+len(data.Hosts)+len(data.Identities)+len(data.Forwards)+len(data.Snippets) > 0
	return data, found, nil
}

// Save replaces all rows in one transaction, so a crash never leaves a half-written state.
func (p StorePersister) Save(d domain.Data) error {
	tx, err := p.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()
	for _, t := range []string{"groups", "hosts", "identities", "port_forwards", "snippets"} {
		if _, err := tx.Exec("DELETE FROM " + t); err != nil {
			return err
		}
	}
	for _, g := range d.Groups {
		if _, err := tx.Exec(`INSERT INTO groups(id,name,parent_id,color,sort_order,updated_at,deleted_at) VALUES(?,?,?,?,?,?,?)`,
			g.ID, g.Name, g.ParentID, g.Color, g.SortOrder, ts(g.UpdatedAt), tsNull(g.DeletedAt)); err != nil {
			return err
		}
	}
	for _, h := range d.Hosts {
		tags, _ := json.Marshal(h.Tags)
		if h.Tags == nil {
			tags = []byte("[]")
		}
		if _, err := tx.Exec(`INSERT INTO hosts(id,label,group_id,hostname,port,username,identity_id,jump_host_id,env,tags,keepalive_sec,created_at,updated_at,deleted_at,os,telnet_enabled,telnet_port,terminal_theme,telnet_username,telnet_encoding) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
			h.ID, h.Label, h.GroupID, h.Hostname, h.Port, h.Username, h.IdentityID, h.JumpHostID, string(h.Env), string(tags),
			h.KeepaliveSec, ts(h.CreatedAt), ts(h.UpdatedAt), tsNull(h.DeletedAt), h.OS, b2i(h.TelnetEnabled), h.TelnetPort, h.TerminalTheme, h.TelnetUsername, h.TelnetEncoding); err != nil {
			return err
		}
	}
	for _, x := range d.Identities {
		if _, err := tx.Exec(`INSERT INTO identities(id,name,username,auth_type,secret_ref,public_key,updated_at,deleted_at,certificate) VALUES(?,?,?,?,?,?,?,?,?)`,
			x.ID, x.Name, x.Username, string(x.AuthType), x.SecretRef, x.PublicKey, ts(x.UpdatedAt), tsNull(x.DeletedAt), x.Certificate); err != nil {
			return err
		}
	}
	for _, f := range d.Forwards {
		if _, err := tx.Exec(`INSERT INTO port_forwards(id,host_id,type,bind_addr,bind_port,dest_host,dest_port,auto_start,allow_public_bind,updated_at,deleted_at,label) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`,
			f.ID, f.HostID, string(f.Type), f.BindAddr, f.BindPort, f.DestHost, f.DestPort, b2i(f.AutoStart), b2i(f.AllowPublicBind), ts(f.UpdatedAt), tsNull(f.DeletedAt), f.Label); err != nil {
			return err
		}
	}
	for _, x := range d.Snippets {
		if _, err := tx.Exec(`INSERT INTO snippets(id,label,description,script,updated_at,deleted_at) VALUES(?,?,?,?,?,?)`,
			x.ID, x.Label, x.Description, x.Script, ts(x.UpdatedAt), tsNull(x.DeletedAt)); err != nil {
			return err
		}
	}
	return tx.Commit()
}

func b2i(b bool) int {
	if b {
		return 1
	}
	return 0
}

// ---- vault.Persister ----

// VaultPersister returns the persister for the encrypted vault.
func (d *DB) VaultPersister() VaultPersister { return VaultPersister{d.db} }

type VaultPersister struct{ db *sql.DB }

var _ vault.Persister = VaultPersister{}

// Load returns nil when no vault has been created.
func (p VaultPersister) Load() (*vault.Snapshot, error) {
	var hdr string
	err := p.db.QueryRow(`SELECT data FROM vault_header WHERE id = 1`).Scan(&hdr)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	snap := &vault.Snapshot{Secrets: []domain.Secret{}}
	if err := json.Unmarshal([]byte(hdr), &snap.Header); err != nil {
		return nil, fmt.Errorf("vault header: %w", err)
	}
	rows, err := p.db.Query(`SELECT id,kind,nonce,ciphertext,updated_at,deleted_at FROM secrets ORDER BY rowid`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var s domain.Secret
		var kind, upd string
		var del sql.NullString
		if err := rows.Scan(&s.ID, &kind, &s.Nonce, &s.Ciphertext, &upd, &del); err != nil {
			return nil, err
		}
		s.Kind, s.UpdatedAt, s.DeletedAt = domain.SecretKind(kind), parseTS(upd), parseTSNull(del)
		snap.Secrets = append(snap.Secrets, s)
	}
	return snap, rows.Err()
}

// Delete removes the header and every secret in one transaction.
func (p VaultPersister) Delete() error {
	tx, err := p.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if _, err := tx.Exec(`DELETE FROM secrets`); err != nil {
		return err
	}
	if _, err := tx.Exec(`DELETE FROM vault_header`); err != nil {
		return err
	}
	return tx.Commit()
}

func (p VaultPersister) Save(s *vault.Snapshot) error {
	hdr, err := json.Marshal(s.Header)
	if err != nil {
		return err
	}
	tx, err := p.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if _, err := tx.Exec(`INSERT INTO vault_header(id,data) VALUES(1,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data`, string(hdr)); err != nil {
		return err
	}
	if _, err := tx.Exec(`DELETE FROM secrets`); err != nil {
		return err
	}
	for _, sec := range s.Secrets {
		if _, err := tx.Exec(`INSERT INTO secrets(id,kind,nonce,ciphertext,updated_at,deleted_at) VALUES(?,?,?,?,?,?)`,
			sec.ID, string(sec.Kind), sec.Nonce, sec.Ciphertext, ts(sec.UpdatedAt), tsNull(sec.DeletedAt)); err != nil {
			return err
		}
	}
	return tx.Commit()
}
